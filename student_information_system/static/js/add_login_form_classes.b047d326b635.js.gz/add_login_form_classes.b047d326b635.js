$(function () {
    $("input").addClass("form-control");
    $("textarea").addClass("form-control");
    $("select").addClass("form-control");
})