$(function() {
    $(".datepicker").datepicker({
        dateFormat: "dd/mm/yy"
    })

    $("select").selectmenu();
})
