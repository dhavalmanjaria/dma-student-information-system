"use strict";

$(function() {
    $(".add-button").click(function() {
        var val = $("#amount_pending").val();
        console.log(val);    
    })
    
});