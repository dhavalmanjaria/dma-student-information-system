$(function () {
    $("input").addClass("form-control");
    $("textarea").addClass("form-control");
});